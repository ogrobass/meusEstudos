<?php

class Categoria {

	public $id;
	public $nome;
}

?>