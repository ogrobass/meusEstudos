# Curso PHP I: Orientação a objetos com sua linguagem preferida

Este repositório mantém o código desenvolvido no [curso PHP I: Orientação a objetos com sua linguagem preferida](https://cursos.alura.com.br/course/php-oo-1) da [Alura](https://www.alura.com.br).
