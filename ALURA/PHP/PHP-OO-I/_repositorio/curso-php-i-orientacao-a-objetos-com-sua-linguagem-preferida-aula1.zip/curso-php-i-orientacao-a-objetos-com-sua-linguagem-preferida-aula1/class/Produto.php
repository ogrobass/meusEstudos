<?php

class Produto {

	public $id;
	public $nome;
	public $preco;
	public $descricao;
	public $categoria_id;
	public $usado;
}

?>