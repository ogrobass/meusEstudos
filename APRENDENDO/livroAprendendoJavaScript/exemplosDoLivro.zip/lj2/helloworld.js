function hello() {
   // say hello to the world
   var msg = "Hello, <em>World!</em>";
   document.open();
   document.write(msg);
   document.close();
}

